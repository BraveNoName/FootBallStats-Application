package com.footballstats.repository;

import com.footballstats.model.MatchEvent;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Collection;
import java.util.List;

@Repository
public interface MatchEventRepository extends JpaRepository<MatchEvent, Long> {

    List<MatchEvent> findByMatchIdOrderByEventMinuteAsc(Long matchId);

    void deleteByMatchIdIn(Collection<Long> matchIds);
}